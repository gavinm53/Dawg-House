document.getElementById("year").textContent = new Date().getFullYear();

const menu = document.querySelector(".menu");
const nav = document.querySelector(".topbar nav");
menu.addEventListener("click", () => {
  nav.style.display = nav.style.display === "flex" ? "" : "flex";
  nav.style.position = "absolute";
  nav.style.top = "65px";
  nav.style.left = "0";
  nav.style.right = "0";
  nav.style.padding = "22px 7vw";
  nav.style.background = "#080808";
  nav.style.flexDirection = "column";
});

function toggleResults() {
  const btn = document.querySelector(".filter");
  btn.textContent = btn.textContent === "SHOW RESULTS" ? "UPCOMING ONLY" : "SHOW RESULTS";
  alert("Schedule data is ready to be connected to a live sports feed.");
}

function bark() {
  const messages = [
    "HOW BOUT THEM DAWGS! 🐶",
    "GATA! GO DAWGS! 🔴⚫",
    "SIC 'EM! 🐶"
  ];
  document.getElementById("bark").textContent =
    messages[Math.floor(Math.random() * messages.length)];
}
