# Between the Hedges — Georgia Football Site

Open `index.html` in a browser to view the site.

Files:
- index.html — page structure/content
- style.css — responsive red/black design
- script.js — mobile navigation and interactive buttons

This is a fan-made site. For live/current team information, connect the schedule/roster sections to an appropriate current data source.
